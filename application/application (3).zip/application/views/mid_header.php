<!--<header class="header bg-success bg-gradient">-->

  <!--
  <ul class="nav nav-tabs">
	<li class="active"><a href="#static" data-toggle="tab">Static table</a></li>
	<li class=""><a href="#datagrid" data-toggle="tab">Datagrid</a></li>
	<li class=""><a href="#datatable" data-toggle="tab">Datatable</a></li>
  </ul>
-->
<header class="header" style="background-color:#fff;">
 </header>