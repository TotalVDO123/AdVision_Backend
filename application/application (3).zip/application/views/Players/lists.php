<?php

defined('BASEPATH') OR exit('No direct script access allowed');
//var_dump($result);die;

?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
			<div class="float-left">
      <ol class="breadcrumb">
        <li><a href="#"></i> Players</a></li>
        <li class="active">All Players</li>
	</ol>
			</div>
			
			<div class="col-sm-12">
				<?php if($message=$this->session->flashdata('message')): 
								$add_class=$this->session->flashdata('add_class');
			?>
				<div class="alert alert-dismissible <?= $add_class ?>">
					<?= $message; ?>
				</div>
			<?php endif; ?>
			</div>
			     
	    <!-- Main content -->
	    <section class="content">
	        <div class="row">
				
				<div class="col-xs-3">
                    <ul class="list-group">
                        <li class="list-group-item"><b>All Users</b></li>
                        <?php 
						
						if(!empty($user)){
                        foreach($user as $results){ ?>
                            <li class="list-group-item"><a href="<?php echo base_url().'index.php/players/index/'.$results['id'];?>"><?php echo  $results['first_name']." ".$results['last_name'];?></a></li>
                        <?php } }else {
                            echo '<li class="list-group-item text-center">No user found!</li>';
                        } ?>
                    </ul>
                </div>
				
				
		        <div class="col-xs-9">
			        <div class="box">
						<div class="row" style="margin-top:20px">
							<div class="col-xs-9">
								<div class="box-header">
									<h3 class="box-title">All Players Details</h3>
								</div>
							</div>
							<div class="col-xs-2 col-xs-offset-1 ">
								
										
								<?php
								if(!empty($user_id))
								{
								?>		
									
									<a href="<?php echo base_url().'index.php/players/add/'.$user_id ?>" class="mt-10">
									<button type="button" class="btn btn-primary">Add Player</button>
									</a>
								<?php
								}
								?>
								
							</div>
						</div>
			            
			            <!-- /.box-header -->
			            <div class="box-body">
			              <table id="example1" class="table table-bordered table-striped">
			                <thead>
			                <tr>
												<th>Player Id</th>
												<th>Player Name</th>
												<th>Player Assign</th>
												<th>Action</th>
			                </tr>
			                </thead>
			                <tbody>
											<?php
											
											//echo '<pre>';
											//print_r($result);
											
											if(!empty($result)){
											foreach ($result as $res) {
											?>
			                
							
							
							
							
							
							<tr>
											 <td><?php echo $res['player_id']; ?></td>
											<td><?php echo $res['name']; ?></td>
											
											<td>
											
											
											<?php
									
									if(!empty($res['assign']))
									{}
									else
									{
											
										$array_assignplayer=array();	
										$sql = "SELECT *  FROM  player_assign_user where 1 and player_id='".$res['id']."'";
                                		
                                		$rec = $this->db->query($sql);
                                		if ($rec->num_rows() > 0) 
                                		{
										
										    $user_assign= $rec->result_array();
    										foreach($user_assign as $user )
                                    		{
                                    		    	$array_assignplayer[]=$user['user_id'];
                                    		}

                                		}
											?>
											
											   
										<select name="userid[]"   class="form-select form-select-lg mb-3 multiuser" aria-label=".form-select-lg example"  data-playerid="<?php echo $res['id']  ?>" multiple>
									       
										<?php
										
										foreach ($assign_users as $user_res) 
										{
										?>

                                <option value="<?php echo $user_res['id'] ?>" <?php if(in_array($user_res['id'],$array_assignplayer)) {  echo 'selected';  } ?>  ><?php echo $user_res['first_name'] ?></option>
										<?php
										}
										?>	    
								</select> 
										
										<?php
										
									}
										?>
											</td>
											
											  <td>
			                  	<a href="<?php echo base_url()."index.php"; ?>/players/single/<?php echo $res['id']; ?>"><i class="fa fa-edit"></i></a> 
			                  	<a onclick="return myConfirmation()" href="<?php echo base_url()."index.php"; ?>/players/delete/<?php echo $res['id']; ?>"><i class="fa fa-trash-o"></i></a>
			                  </td>
			                </tr>
											<?php }
											}else{
												?>
													<td colspan="4" class="text-center">
													<p class="text-left">Please select a user from list on the left side.</p>
													
													
													</td>
											<?php }
											?>
			                </tbody>
			                <tfoot>
			                <tr>
												<th>Player Id</th>
												<th>Player Name</th>
												<th>Player Assign</th>
			                  <th>Action</th>
			                </tr>
			                </tfoot>
			              </table>
			            </div>
			            <!-- /.box-body -->
			        </div>
		        </div>
	         <!-- /.col -->
	        </div>
	      <!-- /.row -->
	    </section>
    </div>
   <!-- ./ Content wrapper -->
  </div> 
  <!-- ./wrapper -->
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
function myConfirmation() {
    var a = confirm("Are You sure To Delete this player");
    if(a)
    {
    	return true;
    }
    else
    {
    	return false;
    }
}
</script>


<script>


$('.multiuser').change(function(e) {
    //alert(e);
    //alert('-----------');
    //console.log(e);
    
    //alert($(e.target).val());

var player_id= $(this).data("playerid");
var user_ids=   $(e.target).val();
     $.ajax({
        url: "<?php echo base_url() ?>index.php/players/playerassign_to_user",
        type: "POST",
        data: {player_id : player_id,user_id:user_ids},
        success: function(result){
            if(result==1)
            alert('This player has been  successfully assigned to user');
        }
    
         
     });
     
     
}); 


    
</script>